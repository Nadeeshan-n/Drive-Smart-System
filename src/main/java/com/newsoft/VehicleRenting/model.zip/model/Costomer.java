package main.java.com.newsoft.VehicleRenting.model;

// Note: This file appears to be a duplicate. 
// The correct Customer class is in Customer.java
// This file can be safely deleted.
