package main.java.com.newsoft.VehicleRenting.model;

public class CostomerForm {
    // This class is intended to store customer form data
    // The Full Name GUI component code provided earlier should be added
    // to your CustomerFormDialog class, not this model class
}
