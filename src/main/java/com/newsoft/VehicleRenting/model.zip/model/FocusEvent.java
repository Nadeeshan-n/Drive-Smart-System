package main.java.com.newsoft.VehicleRenting.model;

public class FocusEvent {

}
